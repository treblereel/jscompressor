/*
 * Copyright 2018 The Closure Compiler Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Definitions for W3C's referrer policy specification.
 * @see https://w3c.github.io/webappsec-referrer-policy/#referrer-policy-delivery
 * @externs
 */

/** @type {string} */
HTMLAnchorElement.prototype.referrerPolicy;

/** @type {string} */
HTMLAreaElement.prototype.referrerPolicy;

/** @type {string} */
HTMLImageElement.prototype.referrerPolicy;

/** @type {string} */
HTMLIFrameElement.prototype.referrerPolicy;

/** @type {string} */
HTMLLinkElement.prototype.referrerPolicy;
